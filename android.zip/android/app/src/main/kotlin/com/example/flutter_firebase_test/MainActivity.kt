package com.example.flutter_firebase_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
